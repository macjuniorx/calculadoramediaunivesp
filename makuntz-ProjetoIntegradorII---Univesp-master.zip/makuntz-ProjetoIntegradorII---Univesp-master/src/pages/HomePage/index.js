import Home from "../../components/Home";

const HomePage = ({user}) => {

    return(
        <div>
            <Home user={user}/>
        </div>
    )
}

export default HomePage;