import Register from "../../components/Register";

const RegisterPage = ({setUser}) => {


    return (
        <div>
            <Register setUser={setUser}/>
        </div>
    )
}

export default RegisterPage;